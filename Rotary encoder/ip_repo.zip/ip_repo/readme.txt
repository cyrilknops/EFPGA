counter is how many steps the rotary encoder does can be positive or negative
use in c:
counter = MY_ROTARY_EN_mReadReg (XPAR_MY_ROTARY_EN_0_S00_AXI_BASEADDR, MY_ROTARY_EN_S00_AXI_SLV_REG3_OFFSET);